<div>
	<ul>
		<li><a href="<?php echo base_url();?>index.php/backend/dashboard">Dashboard</a></li>
		<li><a href="<?php echo base_url();?>index.php/backend/manage_user">Manage User</a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
		<li><a href=""></a></li>
	</ul>
</div>