				
				<!-- Header -->
				<div style="float:left;width:100%;height:11.5%;background:#ebebe8;color:#787878;">
					<div style="margin:0px 20px;width:auto;">	
						<h2 style="text-transform:uppercase;"><i class="fa fa-home" style="margin-right:10px"></i>Dashboard</h2>
					</div>
				</div>
				<!-- End of header -->
				<!-- Separator -->
				<div style="float:left;width:100%;height:0.5%;background:#64c0cc;color:#787878;">
				</div>
				<!-- End of separator -->
				<!-- Work Sheet -->
				<div style="float:left;width:100%;height:80%;background:#fff">
					<!-- Sheet Pertama -->
					<div style="margin:10px 20px;width:auto;background-color:#ffffbf; border-radius:3px; border:1px solid #fcf0d4">
						<div style="width:auto;color:#787878;height:100px;padding:5px 20px;">
							<h3>New Features</h3>
							<hr style="border-color:#fff;"/>
						</div>
					</div>
					<!-- End of sheet pertama -->
					<!-- Sheet kedua -->
					<div style="margin:10px 20px;width:auto;background-color:#ebebe8; border-radius:3px; border:1px solid #ccc">
						<div style="width:auto;color:#787878;padding:5px 20px;">
							<h3>Statistics</h3>
							<hr style="border-color:#fff;"/>
							<div style="background-color:#fff;border:1px solid #ccc; border-radius:3px;padding:10px;margin:20px 0px;">
								<table style="width:100%;border-collapse:collapse;">
									<thead>
										<tr>
											<td style="border-bottom:2px solid #ccc;padding:10px;font-weight:bold">Username</td>
											<td style="border-bottom:2px solid #ccc;padding:10px;font-weight:bold">Name</td>
											<td style="border-bottom:2px solid #ccc;padding:10px;font-weight:bold">Email</td>
											<td style="border-bottom:2px solid #ccc;padding:10px;font-weight:bold">Post</td>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Administrator</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Evan Abeiza</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">evan.abeiza@gmail.com</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">1</td>
										</tr>
										<tr>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Administrator</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Evan Abeiza</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">evan.abeiza@gmail.com</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">1</td>
										</tr>
										<tr>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Administrator</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Evan Abeiza</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">evan.abeiza@gmail.com</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">1</td>
										</tr>
										<tr>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Administrator</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">Evan Abeiza</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">evan.abeiza@gmail.com</td>
											<td style="border-bottom:1px solid #ccc;padding:10px;">1</td>
										</tr>
										<tr>
											<td style="padding:10px;">Administrator</td>
											<td style="padding:10px;">Evan Abeiza</td>
											<td style="padding:10px;">evan.abeiza@gmail.com</td>
											<td style="padding:10px;">1</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<!-- End of sheet kedua -->
					<!-- Sheet ketiga -->
					<div style="margin:10px 20px;width:auto;background-color:#ffffbf; border-radius:3px; border:1px solid #fcf0d4">
						<div style="width:auto;color:#787878;height:100px;padding:5px 20px;">
							<h3>New Features</h3>
							<hr style="border-color:#fff;"/>
						</div>
					</div>
					<!-- End of sheet ketiga -->
				</div>
				<!-- End of Worksheet -->
			</div>
			<!-- End of right side -->