

				<!-- Header -->
				<div style="float:left;width:100%;height:11.5%;background:#ebebe8;color:#787878;">
					<div style="margin:0px 20px;width:auto;">	
						<h2 style="text-transform:uppercase;"><i class="fa fa-home" style="margin-right:10px"></i>HOME</h2>
					</div>
				</div>
				<!-- End of header -->
				<!-- Separator -->
				<div style="float:left;width:100%;height:0.5%;background:#64c0cc;color:#787878;">
				</div>
				<!-- End of separator -->
				<!-- Work Sheet -->
				<div style="float:left;width:100%;height:80%;background:#fff">
					<!-- Sheet Pertama -->
					<div style="margin:10px 20px;width:90%;background-color:#ffffbf; border-radius:3px; border:1px solid #fcf0d4;float:left">
						<div style="width:95%;color:#787878;padding:5px 20px;float:left">
							<div style="width:20%;float:left;">
								<img style="width:90%;background-color:#fff;border-radius:100%;margin:10px;" src="<?php echo base_url().'assets/icon/icon.png'; ?>"/>
							</div>
							<div style="width:80%;float:left">
								<h2>Welcome to Administrator Panel</h2>
								<hr style="border-color:#fff;"/>
								<span>PT Gloria Origita Cosmetics</span>
								<p>This is the screen you will see when you log in to your site, and gives you access to all the site management features of Website CMS.</p>
							</div>
						</div>
					</div>
					<!-- End of sheet pertama -->
				</div>
				<!-- End of Worksheet -->
			</div>
			<!-- End of right side -->