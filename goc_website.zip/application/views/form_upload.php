<?php 
	echo $error;
?>