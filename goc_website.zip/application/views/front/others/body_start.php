<body style="overflow-x: hidden;">

	<!--//headerBg-->
    <div class="headerBg"></div>
    

	<!-- Primary Page Layout
	================================================== -->

	<div class="container home" data-backgroundImage="<?php echo base_url().'assets/template/'; ?>images/backgrounds/home.jpg">