<footer style="background-color:#8dc43f;margin-top:-35px;">
			<!--<div class="footerBgFull" styLe="background-color:#8dc43f"></div>-->
			<div style="padding:20px;background-color:#8dc43f;">
				<div class="footer_menu">
					<span style="padding:20px 10px;"><strong>PRIVACY POLICY</strong></span>
					<span style="padding:20px 10px;"><strong>FAQ</strong></span>
					<span style="padding:20px 10px;"><strong>OUR CONTACT</strong></span>
				</div>
				<div class="footer_copyright">
					<span style="color:#fff;">Copyright &copy;2015 | PT Gloria Origita Cosmetics</span>
				</div>
			</div>
		</footer>
