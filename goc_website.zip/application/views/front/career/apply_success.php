<section class="mainContent">
        <div class="contentBgFull"></div>
        <?php date_default_timezone_set('Asia/Jakarta')?>
        <div id="tagLineShadow" class="sixteen columns"></div>
			<div class="row" style="margin:auto;text-align:center;height:470px;">
				<div style="margin-top: 50px;float: left;">
					<i class="fa fa-check-circle" style="font-size:80px;color:#8dc43f"></i>
					<h1>Terima Kasih Telah Mengirimkan CV Anda !!</h1>
					<div style="width:50%;margin:auto;">
						<span>Tim kami akan Tinjau cv Anda dalam waktu kurang lebih 2 - 4 minggu dari batas waktu penyerahan dan kemudian kami akan menghubungi Anda melalui email atau telepon.</span>
					</div>
					<a href="<?php echo base_url();?>"><i class="fa fa-long-arrow-left"></i> Kembali ke Website</a>
				</div>
			</div>
			<div class="clearfix"></div>
</section>
			